// PathPilot Chart.js Integration

document.addEventListener('DOMContentLoaded', () => {
    loadAnalyticsCharts();
});

function loadAnalyticsCharts() {
    // API GET request to retrieve student data
    fetch('/api/analytics/data')
        .then(response => {
            if (!response.ok) throw new Error('Data endpoint error');
            return response.json();
        })
        .then(data => {
            renderStudyHoursChart(data.days_labels, data.study_hours);
            renderSkillGrowthChart(data.skill_categories, data.skill_progress);
            renderSubjectProgressChart(data.subject_names, data.subject_progress);
            renderReadinessHistoryChart(data.weeks_labels, data.readiness_history);
        })
        .catch(error => {
            console.error('Failed to load chart analytics:', error);
        });
}

// 1. Line Chart: Weekly Study Hours
function renderStudyHoursChart(labels, values) {
    const ctx = document.getElementById('studyHoursChart');
    if (!ctx) return;

    // Check if dark mode is active to adjust grid colors
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? '#1f2937' : '#e2e8f0';
    const textColor = isDark ? '#94a3b8' : '#64748b';

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Study Hours',
                data: values,
                borderColor: '#4f46e5',
                backgroundColor: 'rgba(79, 70, 229, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#4f46e5',
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: gridColor },
                    ticks: { color: textColor },
                    beginAtZero: true
                },
                x: {
                    grid: { display: false },
                    ticks: { color: textColor }
                }
            }
        }
    });
}

// 2. Bar Chart: Skill Category Mastery
function renderSkillGrowthChart(labels, values) {
    const ctx = document.getElementById('skillGrowthChart');
    if (!ctx) return;

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? '#1f2937' : '#e2e8f0';
    const textColor = isDark ? '#94a3b8' : '#64748b';

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Completion %',
                data: values,
                backgroundColor: [
                    'rgba(79, 70, 229, 0.85)', // Programming
                    'rgba(14, 165, 233, 0.85)', // Core CS
                    'rgba(16, 185, 129, 0.85)', // Development
                    'rgba(245, 158, 11, 0.85)',  // AIML
                    'rgba(239, 68, 68, 0.85)'    // Placement
                ],
                borderRadius: 8,
                borderWidth: 0,
                barThickness: 24
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: gridColor },
                    ticks: { color: textColor },
                    max: 100,
                    beginAtZero: true
                },
                x: {
                    grid: { display: false },
                    ticks: { color: textColor }
                }
            }
        }
    });
}

// 3. Bar Chart: Subjects Progress Compare
function renderSubjectProgressChart(labels, values) {
    const ctx = document.getElementById('subjectProgressChart');
    if (!ctx) return;

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? '#1f2937' : '#e2e8f0';
    const textColor = isDark ? '#94a3b8' : '#64748b';

    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: 'Subject Progress %',
                data: values,
                backgroundColor: 'rgba(56, 189, 248, 0.8)',
                borderRadius: 6,
                borderWidth: 0,
                barThickness: 20
            }]
        },
        options: {
            indexAxis: 'y', // horizontal bar chart
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                x: {
                    grid: { color: gridColor },
                    ticks: { color: textColor },
                    max: 100,
                    beginAtZero: true
                },
                y: {
                    grid: { display: false },
                    ticks: { color: textColor }
                }
            }
        }
    });
}

// 4. Line Chart: Placement Readiness History
function renderReadinessHistoryChart(labels, values) {
    const ctx = document.getElementById('readinessHistoryChart');
    if (!ctx) return;

    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    const gridColor = isDark ? '#1f2937' : '#e2e8f0';
    const textColor = isDark ? '#94a3b8' : '#64748b';

    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Readiness Index',
                data: values,
                borderColor: '#10b981',
                backgroundColor: 'rgba(16, 185, 129, 0.05)',
                borderWidth: 3,
                tension: 0.3,
                pointBackgroundColor: '#10b981',
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false }
            },
            scales: {
                y: {
                    grid: { color: gridColor },
                    ticks: { color: textColor },
                    max: 100,
                    beginAtZero: true
                },
                x: {
                    grid: { display: false },
                    ticks: { color: textColor }
                }
            }
        }
    });
}
