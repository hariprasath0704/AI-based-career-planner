// PathPilot Frontend Core Client Logic

document.addEventListener('DOMContentLoaded', () => {
    initTheme();
    initMobileSidebar();
    initWhatShouldIDoNow();
    initSkillRoadmap();
    initDailyScheduleControls();
});

// 1. Light/Dark Theme Switcher
function initTheme() {
    const themeToggleBtn = document.getElementById('themeToggleBtn');
    if (!themeToggleBtn) return;
    
    // Check saved theme or system preference
    const savedTheme = localStorage.getItem('pathpilot-theme');
    const systemPrefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    
    if (savedTheme === 'dark' || (!savedTheme && systemPrefersDark)) {
        document.documentElement.setAttribute('data-theme', 'dark');
        themeToggleBtn.checked = true;
    } else {
        document.documentElement.setAttribute('data-theme', 'light');
        themeToggleBtn.checked = false;
    }
    
    // Event listener for switch toggle
    themeToggleBtn.addEventListener('change', () => {
        if (themeToggleBtn.checked) {
            document.documentElement.setAttribute('data-theme', 'dark');
            localStorage.setItem('pathpilot-theme', 'dark');
        } else {
            document.documentElement.setAttribute('data-theme', 'light');
            localStorage.setItem('pathpilot-theme', 'light');
        }
    });
}

// 2. Mobile Sidebar Navigation Drawer
function initMobileSidebar() {
    const sidebarToggle = document.getElementById('sidebarToggleBtn');
    const sidebar = document.querySelector('.app-sidebar');
    
    if (sidebarToggle && sidebar) {
        sidebarToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            sidebar.classList.toggle('show');
        });
        
        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', (e) => {
            if (sidebar.classList.contains('show') && !sidebar.contains(e.target) && e.target !== sidebarToggle) {
                sidebar.classList.remove('show');
            }
        });
    }
}

// 3. "What Should I Do Now?" Engine Integration
function initWhatShouldIDoNow() {
    const triggerBtn = document.getElementById('whatShouldIDoBtn');
    if (!triggerBtn) return;
    
    const container = document.getElementById('whatShouldIDoResult');
    const spinner = document.getElementById('whatShouldIDoSpinner');
    
    triggerBtn.addEventListener('click', () => {
        // Show spinner, clear old content
        if (container) container.classList.add('d-none');
        if (spinner) spinner.classList.remove('d-none');
        
        // Fetch recommendations from server API
        fetch('/api/what-should-i-do-now')
            .then(response => {
                if (!response.ok) throw new Error('API failure');
                return response.json();
            })
            .then(data => {
                // Populate modal content
                document.getElementById('recTaskName').innerText = data.name;
                document.getElementById('recReason').innerText = data.reason;
                document.getElementById('recTime').innerText = `${data.estimated_time} Minutes`;
                document.getElementById('recBenefit').innerText = data.benefit;
                
                // Priority color badges
                const priorityBadge = document.getElementById('recPriority');
                priorityBadge.innerText = data.priority;
                priorityBadge.className = 'status-badge'; // clear old classes
                
                if (data.priority === 'High') {
                    priorityBadge.classList.add('priority-high');
                } else if (data.priority === 'Medium') {
                    priorityBadge.classList.add('priority-medium');
                } else {
                    priorityBadge.classList.add('priority-low');
                }
                
                // Hide spinner and show container
                if (spinner) spinner.classList.add('d-none');
                if (container) container.classList.remove('d-none');
            })
            .catch(error => {
                console.error('Error recommendation analysis:', error);
                if (spinner) spinner.classList.add('d-none');
                alert('Could not generate recommendation. Please check database configuration.');
            });
    });
}

// 4. Interactive Skills Status Updates (Roadmap)
function initSkillRoadmap() {
    const statusSelectors = document.querySelectorAll('.skill-status-select');
    statusSelectors.forEach(select => {
        select.addEventListener('change', (e) => {
            const skillId = select.dataset.skillId;
            const newStatus = select.value;
            
            // Send update to server API
            fetch('/api/skills/update', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    skill_id: parseInt(skillId),
                    status: newStatus
                })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Visually update the status badge on the card
                    const badge = document.getElementById(`skill-badge-${skillId}`);
                    if (badge) {
                        badge.innerText = newStatus;
                        badge.className = 'status-badge'; // Reset classes
                        
                        const statusClassMap = {
                            'Completed': 'badge-completed',
                            'Practicing': 'badge-practicing',
                            'Learning': 'badge-learning',
                            'Not Started': 'badge-notstarted'
                        };
                        badge.classList.add(statusClassMap[newStatus]);
                    }
                    
                    // Show a quick visual highlight
                    const card = select.closest('.skill-card');
                    if (card) {
                        card.style.borderColor = '#10b981';
                        setTimeout(() => {
                            card.style.borderColor = '';
                        }, 1000);
                    }
                } else {
                    alert('Error: ' + data.error);
                }
            })
            .catch(err => {
                console.error('Failed to update skill status:', err);
                alert('Network connection error.');
            });
        });
    });
}

// 5. Daily Schedule checklist updates
function initDailyScheduleControls() {
    const checkBoxes = document.querySelectorAll('.plan-checkbox');
    checkBoxes.forEach(box => {
        box.addEventListener('change', () => {
            if (!box.checked) return; // ignore unchecking for stability
            
            const planId = box.dataset.planId;
            const row = box.closest('.plan-row');
            
            fetch(`/api/planner/complete/${planId}`, {
                method: 'POST'
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    // Strike out row, fade opacity
                    if (row) {
                        row.style.textDecoration = 'line-through';
                        row.style.opacity = '0.5';
                        box.disabled = true;
                    }
                } else {
                    box.checked = false;
                    alert('Could not update task item.');
                }
            })
            .catch(err => {
                box.checked = false;
                console.error('Error marking activity as complete:', err);
            });
        });
    });
}
